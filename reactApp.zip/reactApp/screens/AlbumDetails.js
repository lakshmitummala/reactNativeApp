import React, { Component } from 'react'
import { View, Text,FlatList,TouchableOpacity,StyleSheet,Dimensions,Image } from 'react-native'

const numColumns = 4;
class AlbumDetails extends Component {
  static navigationOptions = ({ navigation }) => {
    return {
      title: navigation.getParam('name'),
    };
  };
   state = {
      data: ''
   }
   componentDidMount = () => {
      const {params} = this.props.navigation.state;
      let albumId = (params.id);
      this.props.navigation.setParams({title: params.name});
      console.log('https://jsonplaceholder.typicode.com/photos?albumId='+albumId);
      fetch('https://jsonplaceholder.typicode.com/photos?albumId='+albumId, {
         method: 'GET'
      })
      .then((response) => response.json())
      .then((responseJson) => {
         console.log(responseJson);
         this.setState({
            data: responseJson.filter(a => a.key = a.id)
         })
      })
      .catch((error) => {
         console.error(error);
      });
   }
   _onPress = (obj) =>{
    this.props.navigation.navigate('ImgPreview',{url:obj.url,name:obj.title});
   }
   render() {
      return (
        <FlatList style = {styles.container}
    data={this.state.data} numColumns={3}
    renderItem={({item,index}) =><TouchableOpacity onPress={() => this._onPress(item)}  style={styles.item}>
      <View  ><Image style={{width: 70, height: 70}} source={{uri:item.thumbnailUrl}}></Image></View></TouchableOpacity> }
    />
      )
   }   
}
const styles = StyleSheet.create({
  title:{
  padding:5,
  borderColor:'lightgrey',
  },
  container: {
  flex: 1,
  marginVertical: 20,
  },
  item: {
  backgroundColor: '#FFF',
  alignItems: 'center',
  justifyContent: 'center',
  flex: 1,    
  borderRadius:5,
  borderWidth:2,
  margin: 1,
  height: Dimensions.get('window').width / numColumns, // approximate a square
  },
  label:{
  
  }
  });


export default AlbumDetails
import React from 'react';
import {
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Dimensions,
  FlatList,
  Div
} from 'react-native';
import { WebBrowser } from 'expo';

import { MonoText } from '../components/StyledText';
const numColumns = 1;
export default class HomeScreen extends React.Component {
  static navigationOptions = {
    title: "Album's List",
  };

 // static navigationOptions = {title:'Home'}
 state = {
  data: ''
}
componentDidMount = () => {
  fetch('https://jsonplaceholder.typicode.com/albums', {
     method: 'GET'
  })
  .then((response) => response.json())
  .then((responseJson) => {
    fetch('https://jsonplaceholder.typicode.com/users', {
     method: 'GET'
  }).then((users) => users.json())
  .then((usersJson) => {
    responseJson.filter(a => {
      let b = usersJson.filter(c => {
        if(c.id == a.userId){
          a.userName = c.name;
        }
      });
    })
  });
     //console.log(responseJson);
     this.setState({
        data: responseJson.filter(a => a.key = a.id)
     })
  })
  .catch((error) => {
     console.error(error);
  });
}
_onPress = (id) => {
this.props.navigation.navigate('Album',{id:id.id,name:id.title});
};
render() {
 //const {navigate} = this.props.navigation;
  return (
    <FlatList style = {styles.container}
    data={this.state.data} numColumns={numColumns}
    renderItem={({item}) =><TouchableOpacity onPress={() => this._onPress(item)}  style={styles.item}>
      <View><View><Text>Album: {item.title}</Text></View><View><Text style={[styles.title]}>User: {item.userName}</Text></View></View></TouchableOpacity> }
    keyExtractor={(item) => item.key.toString()} />
  )
}
}

const styles = StyleSheet.create({
title:{
padding:5,
borderColor:'lightgrey',
},
container: {
flex: 1,
marginVertical: 20,
},
item: {
backgroundColor: 'lightgrey',
flex: 1,
paddingLeft:10,    
borderRadius:5,
borderWidth:2,
borderColor: 'lightgrey',
margin: 2,
},
label:{

}
});

import React from 'react';
import { ScrollView, StyleSheet,View,Image,Dimensions,StatusBar } from 'react-native';
import { ExpoLinksView } from '@expo/samples';

const WIDTH = Dimensions.get('window').width;
export default class ImgPreview extends React.Component {
    static navigationOptions = ({ navigation }) => {
        return {
          title: navigation.getParam('name'),
        };
      };
  state = {
    url: undefined
  }

  componentDidMount = () => {
    const {params} = this.props.navigation.state;
    console.log(params.url);
    this.setState({
        url: params.url
     }) 
 }

  render() {
    return (
        
      <View style={{flex:1}}><Image style={{flex:1}}  source={{uri:this.state.url}}></Image></View> 
    
      );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 15,
    backgroundColor: '#fff',
  },
});
